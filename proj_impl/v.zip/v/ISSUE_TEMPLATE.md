Before submitting an issue:

- Read this: https://github.com/Valve/fingerprintjs2/blob/master/FAQ.md
- Follow these instructions: https://github.com/Valve/fingerprintjs2/blob/master/CONTRIBUTING.md

1) I checked that my issue is not already fixed in GitHub master:

2) My fingerprint retrieved with [this jsfiddle](https://jsfiddle.net/L2gLq4rg/) is:
   ```
   ...
   ```

3) My device is:
