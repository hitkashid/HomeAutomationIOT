<div class="copyrights">
	 <p>© 2017 . All Rights Reserved |  <a href="#">Unique Bio-identification for security </a> </p>
</div>	
