<div class="sidebar-menu">
					<header class="logo1">
						<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
					</header>
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
									<ul id="menu" >
										
									 
									<li id="menu-academico" ><a href="manage-users.php"><i class="fa fa-users" aria-hidden="true"></i><span>Manage Users</span><div class="clearfix"></div></a></li>
									
									<li id="menu-academico" ><a href="manage-users_2.php"><i class="fa fa-users" aria-hidden="true"></i><span>Recomandation</span><div class="clearfix"></div></a></li>
									
									
							     
									
								  </ul>
								</div>
							  </div>